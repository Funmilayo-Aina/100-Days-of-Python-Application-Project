#1. Create a greeting for your program.
print('Welcome to band-name-generator')
#2. Ask the user for the city that they grew up in.
location=input("What is the city you grew up in?\n" )

#3. Ask the user for the name of a pet.
pet_name = input('What is the name of your pet?\n')
#4. Combine the name of their city and pet and show them their band name.
band_name =  location + " " + pet_name
print(band_name)
#5. Make sure the input cursor shows on a new line, see the example at: https://replit.com/@appbrewery/band-name-generator-end